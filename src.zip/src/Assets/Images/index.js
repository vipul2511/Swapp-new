import Slider2Logo from './slider2_logo.svg';
